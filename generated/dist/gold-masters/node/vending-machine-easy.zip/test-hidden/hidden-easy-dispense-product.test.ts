import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { VendingMachineService } from '../src/services/VendingMachineService';
import db from '../src/db';

let service;

before(() => {
  // Start the application server
  // Assume the server is started here
});

after(() => {
  // Close the application server
  // Assume the server is closed here
});

beforeEach(() => {
  // Reset the database to a known state
  db.exec(`
    DELETE FROM transactions;
    UPDATE products SET quantity = 10 WHERE id = 1;
    UPDATE products SET quantity = 5 WHERE id = 2;
    UPDATE products SET quantity = 20 WHERE id = 3;
  `);
  service = new VendingMachineService();
});

test('Happy path: Dispense product with exact amount', () => {
  const change = service.dispenseProduct(1, 150);
  assert.strictEqual(change, 0, 'Change should be 0 when exact amount is paid');
});

test('Happy path: Dispense product with more than required amount', () => {
  const change = service.dispenseProduct(1, 200);
  assert.strictEqual(change, 50, 'Change should be 50 when 200 is paid for a 150 product');
});

test('Not found: Non-existent product ID', () => {
  assert.throws(() => service.dispenseProduct(999, 150), /Product not found/, 'Should throw error for non-existent product');
});

test('Out of stock: Product with zero quantity', () => {
  db.exec('UPDATE products SET quantity = 0 WHERE id = 1');
  assert.throws(() => service.dispenseProduct(1, 150), /Product is out of stock/, 'Should throw OutOfStockException for zero quantity');
});

test('Insufficient funds: Less than product price', () => {
  assert.throws(() => service.dispenseProduct(1, 100), /Insufficient funds provided/, 'Should throw InsufficientFundsException for insufficient payment');
});

test('State consistency: Quantity decreases after purchase', () => {
  service.dispenseProduct(1, 150);
  const product = db.prepare('SELECT * FROM products WHERE id = 1').get();
  assert.strictEqual(product.quantity, 9, 'Product quantity should decrease by 1 after purchase');
});

test('Idempotency: Same transaction twice', () => {
  const change1 = service.dispenseProduct(1, 150);
  const change2 = service.dispenseProduct(1, 150);
  assert.strictEqual(change1, 0, 'First transaction should return correct change');
  assert.strictEqual(change2, 0, 'Second transaction should return correct change');
});

test('Boundary values: Zero amount paid', () => {
  assert.throws(() => service.dispenseProduct(1, 0), /Insufficient funds provided/, 'Should throw InsufficientFundsException for zero payment');
});

test('Boundary values: Exact amount paid', () => {
  const change = service.dispenseProduct(2, 100);
  assert.strictEqual(change, 0, 'Change should be 0 when exact amount is paid');
});

test('Boundary values: Negative amount paid', () => {
  assert.throws(() => service.dispenseProduct(1, -50), /Insufficient funds provided/, 'Should throw InsufficientFundsException for negative payment');
});

test('State consistency: Transaction recorded correctly', () => {
  service.dispenseProduct(1, 150);
  const transaction = db.prepare('SELECT * FROM transactions WHERE product_id = 1').get();
  assert.strictEqual(transaction.amount_paid, 150, 'Transaction should record the correct amount paid');
  assert.strictEqual(transaction.change_given, 0, 'Transaction should record the correct change given');
  assert.strictEqual(transaction.status, 'completed', 'Transaction should have status completed');
});

test('Forbidden: Attempt to dispense with insufficient funds', () => {
  assert.throws(() => service.dispenseProduct(1, 50), /Insufficient funds provided/, 'Should throw InsufficientFundsException for insufficient payment');
});

test('Validation: Non-numeric product ID', () => {
  assert.throws(() => service.dispenseProduct('abc', 150), /Product not found/, 'Should throw error for non-numeric product ID');
});

test('Validation: Non-numeric amount paid', () => {
  assert.throws(() => service.dispenseProduct(1, 'abc'), /Insufficient funds provided/, 'Should throw InsufficientFundsException for non-numeric payment');
});

test('Validation: Missing product ID', () => {
  assert.throws(() => service.dispenseProduct(undefined, 150), /Product not found/, 'Should throw error for missing product ID');
});

test('Validation: Missing amount paid', () => {
  assert.throws(() => service.dispenseProduct(1, undefined), /Insufficient funds provided/, 'Should throw InsufficientFundsException for missing payment');
});
