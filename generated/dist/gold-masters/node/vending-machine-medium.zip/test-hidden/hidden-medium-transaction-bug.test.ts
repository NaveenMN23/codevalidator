import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { VendingMachineService } from '../src/vending/VendingMachineService';
import db from '../src/db';
import { execSync } from 'child_process';

let service;

before(() => {
  execSync('npm start &');
});

after(() => {
  execSync('pkill -f "node src/index.js"');
});

beforeEach(() => {
  service = new VendingMachineService();
  db.exec(`
    DELETE FROM transactions;
    UPDATE products SET quantity = 10 WHERE id = 1;
    UPDATE coins SET quantity = 10;
  `);
});

test('Correct behaviour: returns correct change', () => {
  const result = service.processTransaction(1, 200);
  assert.deepEqual(result.change, [
    { denomination: 50, count: 1 }
  ], 'Should return correct change of 50');
});

test('Bug regression: incorrect change when lower denominations run out', () => {
  db.exec('UPDATE coins SET quantity = 0 WHERE denomination = 50');
  assert.throws(() => {
    service.processTransaction(1, 200);
  }, /Unable to provide exact change/, 'Should throw error when unable to provide exact change');
});

test('Not found: product does not exist', () => {
  assert.throws(() => {
    service.processTransaction(999, 200);
  }, /Product out of stock/, 'Should throw error for non-existent product');
});

test('Forbidden: insufficient funds', () => {
  assert.throws(() => {
    service.processTransaction(1, 100);
  }, /Insufficient funds/, 'Should throw error for insufficient funds');
});

test('Boundary values: exact amount paid', () => {
  const result = service.processTransaction(1, 150);
  assert.deepEqual(result.change, [], 'Should return no change for exact payment');
});

test('State consistency: product quantity reduced', () => {
  service.processTransaction(1, 200);
  const product = db.prepare('SELECT * FROM products WHERE id = 1').get();
  assert.strictEqual(product.quantity, 9, 'Product quantity should be reduced by 1');
});

test('Idempotency: repeated transaction', () => {
  service.processTransaction(1, 200);
  const result = service.processTransaction(1, 200);
  assert.deepEqual(result.change, [
    { denomination: 50, count: 1 }
  ], 'Should return correct change on repeated transaction');
});

test('Side effects: coin quantities updated', () => {
  service.processTransaction(1, 200);
  const coins = db.prepare('SELECT * FROM coins WHERE denomination = 50').get();
  assert.strictEqual(coins.quantity, 9, 'Coin quantity should be reduced by 1 for 50 denomination');
});

test('Type edge cases: large amount paid', () => {
  const result = service.processTransaction(1, 1000);
  assert.deepEqual(result.change, [
    { denomination: 100, count: 8 },
    { denomination: 50, count: 1 }
  ], 'Should return correct change for large payment');
});
