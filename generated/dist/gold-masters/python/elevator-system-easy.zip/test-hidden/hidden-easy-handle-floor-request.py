import pytest
import httpx
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.index import app
from src.database import Base, get_db
from src.models.Elevator import Elevator
from src.dtos.ElevatorDTO import FloorRequestDTO

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="function")
def db_session():
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)

@pytest.fixture(scope="function")
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            db_session.close()
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c

@pytest.mark.asyncio
async def test_handle_floor_request_happy_path(client, db_session):
    elevator = Elevator(id=1, current_floor=1, target_floors="", direction="idle", is_moving=False)
    db_session.add(elevator)
    db_session.commit()

    request_data = {"floor_number": 5, "direction": "up", "elevator_id": 1}
    response = client.post("/api/elevator/request", json=request_data)

    assert response.status_code == 200
    assert response.json() == {"message": "Floor request added successfully"}

    updated_elevator = db_session.query(Elevator).filter(Elevator.id == 1).first()
    assert updated_elevator.target_floors == "5"
    assert updated_elevator.direction == "up"
    assert updated_elevator.is_moving is True

@pytest.mark.asyncio
async def test_handle_floor_request_invalid_floor(client, db_session):
    elevator = Elevator(id=1, current_floor=1, target_floors="", direction="idle", is_moving=False)
    db_session.add(elevator)
    db_session.commit()

    request_data = {"floor_number": 101, "direction": "up", "elevator_id": 1}
    response = client.post("/api/elevator/request", json=request_data)

    assert response.status_code == 400
    assert "Invalid floor number" in response.json()["detail"]

@pytest.mark.asyncio
async def test_handle_floor_request_elevator_not_found(client, db_session):
    request_data = {"floor_number": 5, "direction": "up", "elevator_id": 999}
    response = client.post("/api/elevator/request", json=request_data)

    assert response.status_code == 400
    assert "Elevator not found" in response.json()["detail"]

@pytest.mark.asyncio
async def test_handle_floor_request_floor_already_in_queue(client, db_session):
    elevator = Elevator(id=1, current_floor=1, target_floors="5", direction="up", is_moving=True)
    db_session.add(elevator)
    db_session.commit()

    request_data = {"floor_number": 5, "direction": "up", "elevator_id": 1}
    response = client.post("/api/elevator/request", json=request_data)

    assert response.status_code == 200
    assert response.json() == {"message": "Floor request added successfully"}

    updated_elevator = db_session.query(Elevator).filter(Elevator.id == 1).first()
    assert updated_elevator.target_floors == "5"
    assert updated_elevator.direction == "up"
    assert updated_elevator.is_moving is True

@pytest.mark.asyncio
async def test_handle_floor_request_boundary_values(client, db_session):
    elevator = Elevator(id=1, current_floor=1, target_floors="", direction="idle", is_moving=False)
    db_session.add(elevator)
    db_session.commit()

    request_data = {"floor_number": 0, "direction": "up", "elevator_id": 1}
    response = client.post("/api/elevator/request", json=request_data)

    assert response.status_code == 200
    assert response.json() == {"message": "Floor request added successfully"}

    updated_elevator = db_session.query(Elevator).filter(Elevator.id == 1).first()
    assert updated_elevator.target_floors == "0"
    assert updated_elevator.direction == "down"
    assert updated_elevator.is_moving is True

@pytest.mark.asyncio
async def test_handle_floor_request_idempotency(client, db_session):
    elevator = Elevator(id=1, current_floor=1, target_floors="", direction="idle", is_moving=False)
    db_session.add(elevator)
    db_session.commit()

    request_data = {"floor_number": 5, "direction": "up", "elevator_id": 1}
    response1 = client.post("/api/elevator/request", json=request_data)
    response2 = client.post("/api/elevator/request", json=request_data)

    assert response1.status_code == 200
    assert response2.status_code == 200
    assert response1.json() == response2.json()

    updated_elevator = db_session.query(Elevator).filter(Elevator.id == 1).first()
    assert updated_elevator.target_floors == "5"
    assert updated_elevator.direction == "up"
    assert updated_elevator.is_moving is True
