import pytest
import httpx
from fastapi.testclient import TestClient
from src.index import app
from src.db import get_db, seed_data
from sqlalchemy.orm import Session

@pytest.fixture(scope='function')
def client():
    seed_data()  # Reset and seed the database before each test
    with TestClient(app) as c:
        yield c

@pytest.mark.asyncio
async def test_park_vehicle_happy_path(client):
    response = client.post('/api/park', json={'vehicle_id': 1})
    assert response.status_code == 200
    data = response.json()
    assert 'ticket_id' in data
    assert data['vehicle_id'] == 1
    assert data['parking_spot_id'] in [1, 2]
    assert 'entry_time' in data

@pytest.mark.asyncio
async def test_park_vehicle_no_available_spots(client):
    # Occupy all spots first
    client.post('/api/park', json={'vehicle_id': 1})
    client.post('/api/park', json={'vehicle_id': 2})
    response = client.post('/api/park', json={'vehicle_id': 1})
    assert response.status_code == 404
    assert response.json()['detail'] == 'No available parking spots'

@pytest.mark.asyncio
async def test_park_vehicle_vehicle_not_found(client):
    response = client.post('/api/park', json={'vehicle_id': 999})
    assert response.status_code == 404
    assert response.json()['detail'] == 'Vehicle not found'

@pytest.mark.asyncio
async def test_park_vehicle_invalid_request(client):
    response = client.post('/api/park', json={})
    assert response.status_code == 422

@pytest.mark.asyncio
async def test_park_vehicle_boundary_values(client):
    response = client.post('/api/park', json={'vehicle_id': 0})
    assert response.status_code == 404

    response = client.post('/api/park', json={'vehicle_id': -1})
    assert response.status_code == 404

@pytest.mark.asyncio
async def test_park_vehicle_state_consistency(client):
    response = client.post('/api/park', json={'vehicle_id': 1})
    assert response.status_code == 200
    data = response.json()
    ticket_id = data['ticket_id']

    # Check the database directly
    db: Session = next(get_db())
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    assert ticket is not None
    assert ticket.vehicle_id == 1
    assert ticket.parking_spot.is_occupied is True

@pytest.mark.asyncio
async def test_park_vehicle_idempotency(client):
    response1 = client.post('/api/park', json={'vehicle_id': 1})
    response2 = client.post('/api/park', json={'vehicle_id': 1})
    assert response1.status_code == 200
    assert response2.status_code == 404  # No available spots after first park

@pytest.mark.asyncio
async def test_park_vehicle_forbidden(client):
    # Assuming some logic for forbidden access, e.g., user roles, not implemented here
    pass

@pytest.mark.asyncio
async def test_park_vehicle_unicode_handling(client):
    # Assuming vehicle_id is an integer, unicode test not applicable here
    pass

@pytest.mark.asyncio
async def test_park_vehicle_concurrency(client):
    # Assuming concurrency test setup, not implemented here
    pass
