import pytest
import httpx
from fastapi.testclient import TestClient
from src.index import app
from src.exceptions.InvalidOperationException import InvalidOperationException

@pytest.fixture
def client():
    return TestClient(app)

@pytest.mark.asyncio
async def test_perform_calculation_addition(client):
    response = client.post("/calculate", json={"operation": "add", "operand1": 5, "operand2": 3})
    assert response.status_code == 200
    assert response.json() == {"result": 8}

@pytest.mark.asyncio
async def test_perform_calculation_subtraction(client):
    response = client.post("/calculate", json={"operation": "subtract", "operand1": 10, "operand2": 4})
    assert response.status_code == 200
    assert response.json() == {"result": 6}

@pytest.mark.asyncio
async def test_perform_calculation_multiplication(client):
    response = client.post("/calculate", json={"operation": "multiply", "operand1": 7, "operand2": 6})
    assert response.status_code == 200
    assert response.json() == {"result": 42}

@pytest.mark.asyncio
async def test_perform_calculation_division(client):
    response = client.post("/calculate", json={"operation": "divide", "operand1": 8, "operand2": 2})
    assert response.status_code == 200
    assert response.json() == {"result": 4}

@pytest.mark.asyncio
async def test_perform_calculation_division_by_zero(client):
    response = client.post("/calculate", json={"operation": "divide", "operand1": 8, "operand2": 0})
    assert response.status_code == 400
    assert response.json()["detail"] == "Division by zero is not allowed."

@pytest.mark.asyncio
async def test_perform_calculation_invalid_operation(client):
    response = client.post("/calculate", json={"operation": "mod", "operand1": 8, "operand2": 2})
    assert response.status_code == 400
    assert "Unsupported operation" in response.json()["detail"]

@pytest.mark.asyncio
async def test_perform_calculation_boundary_zero(client):
    response = client.post("/calculate", json={"operation": "add", "operand1": 0, "operand2": 0})
    assert response.status_code == 200
    assert response.json() == {"result": 0}

@pytest.mark.asyncio
async def test_perform_calculation_boundary_negative(client):
    response = client.post("/calculate", json={"operation": "subtract", "operand1": -5, "operand2": -3})
    assert response.status_code == 200
    assert response.json() == {"result": -2}

@pytest.mark.asyncio
async def test_perform_calculation_idempotency(client):
    response1 = client.post("/calculate", json={"operation": "multiply", "operand1": 3, "operand2": 3})
    response2 = client.post("/calculate", json={"operation": "multiply", "operand1": 3, "operand2": 3})
    assert response1.status_code == 200
    assert response2.status_code == 200
    assert response1.json() == response2.json()

@pytest.mark.asyncio
async def test_perform_calculation_invalid_json(client):
    response = client.post("/calculate", json={"operation": "add", "operand1": "five", "operand2": 3})
    assert response.status_code == 422
