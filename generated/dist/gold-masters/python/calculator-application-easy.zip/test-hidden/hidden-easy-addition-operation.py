import pytest
import httpx
from fastapi.testclient import TestClient
from src.index import app
from src.models.Calculation import Calculation
from src.repositories.CalculationRepository import CalculationRepository

@pytest.fixture(autouse=True)
def setup_and_teardown():
    # Setup: Reset the repository or database
    # This is a placeholder for actual database reset logic
    CalculationRepository._calculations = []
    yield
    # Teardown: Clean up any state if necessary

@pytest.mark.asyncio
def test_addition_happy_path():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 5, "operand2": 10, "operation": "add"})
        assert response.status_code == 200
        data = response.json()
        assert data["result"] == 15
        assert data["operand1"] == 5
        assert data["operand2"] == 10
        assert data["operation"] == "add"

@pytest.mark.asyncio
def test_addition_invalid_operands():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": "five", "operand2": 10, "operation": "add"})
        assert response.status_code == 400
        assert "Operands must be numbers" in response.text

@pytest.mark.asyncio
def test_addition_not_found():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 999999, "operand2": 999999, "operation": "add"})
        assert response.status_code == 200
        data = response.json()
        assert data["result"] == 1999998

@pytest.mark.asyncio
def test_addition_forbidden():
    # This test is a placeholder as the current implementation does not have user roles
    pass

@pytest.mark.asyncio
def test_addition_validation_error():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 5})
        assert response.status_code == 422

@pytest.mark.asyncio
def test_addition_boundary_values():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 0, "operand2": 0, "operation": "add"})
        assert response.status_code == 200
        data = response.json()
        assert data["result"] == 0

@pytest.mark.asyncio
def test_addition_state_consistency():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        await client.post("/calculator/add", json={"operand1": 5, "operand2": 10, "operation": "add"})
        # Directly query the repository or database to verify
        assert len(CalculationRepository._calculations) == 1
        assert CalculationRepository._calculations[0].result == 15

@pytest.mark.asyncio
def test_addition_idempotency():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response1 = await client.post("/calculator/add", json={"operand1": 5, "operand2": 10, "operation": "add"})
        response2 = await client.post("/calculator/add", json={"operand1": 5, "operand2": 10, "operation": "add"})
        assert response1.json() == response2.json()

@pytest.mark.asyncio
def test_addition_partial_data():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 5, "operation": "add"})
        assert response.status_code == 422

@pytest.mark.asyncio
def test_addition_type_edge_cases():
    async with httpx.AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/calculator/add", json={"operand1": 1e308, "operand2": 1e308, "operation": "add"})
        assert response.status_code == 200
        data = response.json()
        assert data["result"] == float('inf')
