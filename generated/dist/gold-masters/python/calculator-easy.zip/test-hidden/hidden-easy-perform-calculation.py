import pytest
import httpx
from fastapi.testclient import TestClient
from src.index import app
from src.exceptions.InvalidOperationException import InvalidOperationException

@pytest.fixture
def client():
    return TestClient(app)

@pytest.mark.asyncio
def test_perform_calculation_add(client):
    response = client.post("/api/calculate", json={"operand1": 5, "operand2": 3, "operation": "add"})
    assert response.status_code == 200
    assert response.json() == {"result": 8}

@pytest.mark.asyncio
def test_perform_calculation_subtract(client):
    response = client.post("/api/calculate", json={"operand1": 5, "operand2": 3, "operation": "subtract"})
    assert response.status_code == 200
    assert response.json() == {"result": 2}

@pytest.mark.asyncio
def test_perform_calculation_multiply(client):
    response = client.post("/api/calculate", json={"operand1": 5, "operand2": 3, "operation": "multiply"})
    assert response.status_code == 200
    assert response.json() == {"result": 15}

@pytest.mark.asyncio
def test_perform_calculation_divide(client):
    response = client.post("/api/calculate", json={"operand1": 6, "operand2": 3, "operation": "divide"})
    assert response.status_code == 200
    assert response.json() == {"result": 2}

@pytest.mark.asyncio
def test_perform_calculation_divide_by_zero(client):
    response = client.post("/api/calculate", json={"operand1": 6, "operand2": 0, "operation": "divide"})
    assert response.status_code == 400
    assert "Cannot divide by zero" in response.json()["detail"]

@pytest.mark.asyncio
def test_perform_calculation_invalid_operation(client):
    response = client.post("/api/calculate", json={"operand1": 6, "operand2": 3, "operation": "modulus"})
    assert response.status_code == 400
    assert "Invalid operation: modulus" in response.json()["detail"]

@pytest.mark.asyncio
def test_perform_calculation_missing_fields(client):
    response = client.post("/api/calculate", json={"operand1": 6, "operation": "add"})
    assert response.status_code == 422

@pytest.mark.asyncio
def test_perform_calculation_boundary_values(client):
    response = client.post("/api/calculate", json={"operand1": 0, "operand2": 0, "operation": "add"})
    assert response.status_code == 200
    assert response.json() == {"result": 0}

@pytest.mark.asyncio
def test_perform_calculation_large_numbers(client):
    response = client.post("/api/calculate", json={"operand1": 1e308, "operand2": 1e308, "operation": "add"})
    assert response.status_code == 200
    assert response.json()["result"] == float('inf')

@pytest.mark.asyncio
def test_perform_calculation_negative_numbers(client):
    response = client.post("/api/calculate", json={"operand1": -5, "operand2": -3, "operation": "add"})
    assert response.status_code == 200
    assert response.json() == {"result": -8}