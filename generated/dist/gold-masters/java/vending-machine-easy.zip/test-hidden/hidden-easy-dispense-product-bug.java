package com.challenge;

import com.challenge.dtos.ProductDTO;
import com.challenge.exceptions.InsufficientFundsException;
import com.challenge.exceptions.OutOfStockException;
import com.challenge.models.Product;
import com.challenge.repositories.ProductRepository;
import com.challenge.services.VendingMachineService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class VendingMachineServiceHiddenTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private VendingMachineService vendingMachineService;

    @BeforeEach
    public void setup() {
        productRepository.deleteAll();
        productRepository.save(new Product(1, "Soda", 1.50, 10));
        productRepository.save(new Product(2, "Chips", 1.00, 5));
        productRepository.save(new Product(3, "Candy", 0.75, 20));
        productRepository.save(new Product(4, "Juice", 2.00, 8));
    }

    @Test
    public void testDispenseProductCorrectBehaviour() throws InsufficientFundsException, OutOfStockException {
        vendingMachineService.dispenseProduct(1, 1.50);
        Product product = productRepository.findById(1).orElseThrow();
        assertEquals(9, product.getQuantity(), "Product quantity should be decremented by 1.");
    }

    @Test
    public void testDispenseProductBugRegression() throws InsufficientFundsException, OutOfStockException {
        vendingMachineService.dispenseProduct(1, 1.50);
        Product product = productRepository.findById(1).orElseThrow();
        assertNotEquals(10, product.getQuantity(), "Product quantity should not remain the same after dispensing.");
    }

    @Test
    public void testDispenseProductNotFound() {
        Exception exception = assertThrows(OutOfStockException.class, () -> {
            vendingMachineService.dispenseProduct(999, 1.50);
        });
        assertEquals("Product not found.", exception.getMessage());
    }

    @Test
    public void testDispenseProductForbidden() {
        Exception exception = assertThrows(InsufficientFundsException.class, () -> {
            vendingMachineService.dispenseProduct(1, 1.00);
        });
        assertEquals("Insufficient funds.", exception.getMessage());
    }

    @Test
    public void testDispenseProductBoundaryValues() throws InsufficientFundsException, OutOfStockException {
        vendingMachineService.dispenseProduct(3, 0.75);
        Product product = productRepository.findById(3).orElseThrow();
        assertEquals(19, product.getQuantity(), "Product quantity should be decremented by 1.");
    }

    @Test
    public void testDispenseProductStateConsistency() throws InsufficientFundsException, OutOfStockException {
        vendingMachineService.dispenseProduct(2, 1.00);
        Product product = productRepository.findById(2).orElseThrow();
        assertEquals(4, product.getQuantity(), "Product quantity should be decremented by 1.");
    }

    @Test
    public void testDispenseProductIdempotency() throws InsufficientFundsException, OutOfStockException {
        vendingMachineService.dispenseProduct(4, 2.00);
        vendingMachineService.dispenseProduct(4, 2.00);
        Product product = productRepository.findById(4).orElseThrow();
        assertEquals(6, product.getQuantity(), "Product quantity should be decremented by 2 after two transactions.");
    }
}