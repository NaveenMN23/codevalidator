package com.challenge;

import com.challenge.dtos.ProductDTO;
import com.challenge.exceptions.InsufficientFundsException;
import com.challenge.exceptions.OutOfStockException;
import com.challenge.models.Product;
import com.challenge.repositories.ProductRepository;
import com.challenge.services.VendingMachineService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class VendingMachineServiceTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private VendingMachineService vendingMachineService;

    @BeforeEach
    public void setup() {
        // Reset the database to a known state
        productRepository.deleteAll();
        productRepository.save(new Product(1, "Soda", 1.25, 10));
        productRepository.save(new Product(2, "Chips", 1.00, 15));
        productRepository.save(new Product(3, "Candy", 0.75, 20));
    }

    @Test
    public void testDispenseProductHappyPath() {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setAmountPaid(2.00);

        ResponseEntity<String> response = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Product dispensed successfully", response.getBody());

        Optional<Product> product = productRepository.findById(1);
        assertTrue(product.isPresent());
        assertEquals(9, product.get().getQuantity());
    }

    @Test
    public void testDispenseProductOutOfStock() {
        Product product = productRepository.findById(1).get();
        product.setQuantity(0);
        productRepository.save(product);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setAmountPaid(2.00);

        ResponseEntity<String> response = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Product is out of stock", response.getBody());
    }

    @Test
    public void testDispenseProductInsufficientFunds() {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setAmountPaid(1.00);

        ResponseEntity<String> response = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Insufficient funds", response.getBody());
    }

    @Test
    public void testDispenseProductNotFound() {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(999);
        productDTO.setAmountPaid(2.00);

        ResponseEntity<String> response = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Product not found", response.getBody());
    }

    @Test
    public void testDispenseProductBoundaryValues() {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setAmountPaid(1.25);

        ResponseEntity<String> response = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Product dispensed successfully", response.getBody());

        Optional<Product> product = productRepository.findById(1);
        assertTrue(product.isPresent());
        assertEquals(9, product.get().getQuantity());
    }

    @Test
    public void testDispenseProductIdempotency() {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setAmountPaid(2.00);

        ResponseEntity<String> response1 = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);
        ResponseEntity<String> response2 = restTemplate.postForEntity("/vending-machine/dispense", productDTO, String.class);

        assertEquals(HttpStatus.OK, response1.getStatusCode());
        assertEquals("Product dispensed successfully", response1.getBody());

        assertEquals(HttpStatus.OK, response2.getStatusCode());
        assertEquals("Product dispensed successfully", response2.getBody());

        Optional<Product> product = productRepository.findById(1);
        assertTrue(product.isPresent());
        assertEquals(8, product.get().getQuantity());
    }
}